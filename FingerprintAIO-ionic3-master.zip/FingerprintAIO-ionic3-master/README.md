Source: <br />
https://ionicframework.com/docs/native/fingerprint-aio/

Works for ANDROID (Tested) + IOS (Tested) <br />

  if fingerprint sensor is not available sowing message that it's not available.

$ ionic cordova plugin add cordova-plugin-fingerprint-aio <br />
$ npm install --save @ionic-native/fingerprint-aio

================================================ <br />
$ ionic info

cli packages:

    @ionic/cli-utils  : 1.19.0
    ionic (Ionic CLI) : 3.19.0

global packages:

    cordova (Cordova CLI) : 7.1.0

local packages:

    @ionic/app-scripts : 3.1.6
    Cordova Platforms  : android 6.3.0
    Ionic Framework    : ionic-angular 3.9.2

System:

    Android SDK Tools : 26.1.1
    Node              : v6.11.5
    npm               : 5.5.1
    OS                : Windows 10

Misc:

    backend : pro



================================================
